package com.sist.main;

public class mainClass_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
