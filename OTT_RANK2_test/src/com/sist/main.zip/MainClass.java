package com.sist.main;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("서동현");
		System.out.println("이철우");
		System.out.println("지은표");
		System.out.println("김한별");
		System.out.println("이성현");
		System.out.println("홍은서");
		
	}

}
